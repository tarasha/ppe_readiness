<#
.Synopsis
    Azure Sql Databases - Dummy Data Population
 .DESCRIPTIOn
    This script is used to populate dummy data for use with the WingtipTickets application.
 .EXAMPLE
    Populate-DBSchema 'ServerName', 'UserName', 'Password', 'DatabaseName'
 .INPUTS
    1. ServerName
        Azure sql database server name for connection.
    2. UserName
        Username for sql database connection.
    3. Password
        Password for sql database connection.
    4. DatabaseName
        Azure Sql Database Name
    
 .OUTPUTS
    By executing this script, you will receive messages regarding success or failure of data Insertion.
 .NOTES
    The server name, user name, and password parameters are mandatory.
#>
function Populate-DBSchema
{
    [CmdletBinding()]
    Param
    (
        #Azure SQL server name for connection.
        [Parameter(Mandatory=$true)]
        [String]
        $ServerName,
        #Azure SQL db user name for connection.
        [Parameter(Mandatory=$true)]
        [String]
        $UserName,
        #Azure SQL db password for connection.
        [Parameter(Mandatory=$true)]
        [String]
        $Password,
        #Azure SQL database name.
        [Parameter(Mandatory=$true)]
        [String]
        $DatabaseName
    )
    Process
    {
        Try
        {
            Write-Host "Beginning to refresh and populate database with data..." -ForegroundColor Yellow

            #CUSTOMERS
            Write-Host "Connecting to Customers tables..."
            $CustomersConnectionString = "Server=tcp:$ServerName.database.windows.net;Database=$DatabaseName;User ID=$UserName;Password=$Password;Trusted_Connection=False;Encrypt=True;"
            $CustomersConnection = New-Object System.Data.SqlClient.SqlConnection($CustomersConnectionString)
            $CustomersCommand = New-Object System.Data.SqlClient.SqlCommand('',$CustomersConnection)
            $CustomersConnection.Open()
            Write-Host "Connected to Customers tables successfully."
            Write-Host "Beginning to clean Customers tables..."
            $CustomersCommand.CommandText = "Delete From Customers"
            $Result = $CustomersCommand.ExecuteNonQuery()
            $CustomersCommand.CommandText = "Delete From Organizers"
            $Result = $CustomersCommand.ExecuteNonQuery()
            Write-Host "Finished cleaning Customers tables."
            $CustomersCommand.CommandText =
@"
                Set Identity_Insert [dbo].[Customers] On 
                Insert [dbo].[Customers] ([CustomerId], [FirstName], [LastName], [Email], [Password]) Values (1, N'admin', N'admin', N'admin@admin.com', N'P@ssword1')
                Set Identity_Insert [dbo].[Customers] Off
"@
            $Result = $CustomersCommand.ExecuteNonQuery()
            Write-Host "Table 'Customers' populated with data successfully."
            Write-Host "Closing connection to Customers tables..."
            $CustomersConnection.Close()
            $CustomersConnection = $null
            $CustomersCommand = $null
            $CustomersConnectionString = $null
            Write-Host "Closed connection and finished processing Customers tables." -ForegroundColor Yellow
            
            #VENUES            
            Write-Host "Connecting to Venues tables..."
            $VenuesConnectionString = "Server=tcp:$ServerName.database.windows.net;Database=$DatabaseName;User ID=$UserName;Password=$Password;Trusted_Connection=False;Encrypt=True;"
            $VenuesConnection = New-Object System.Data.SqlClient.SqlConnection($VenuesConnectionString)
            $VenuesCommand = New-Object System.Data.SqlClient.SqlCommand('',$VenuesConnection)
            $VenuesConnection.Open()
            Write-Host "Connected to Venues tables successfully."
            Write-Host "Beginning to clean Venues tables..."
            $VenuesCommand.CommandText = "Delete From SeatSection"
            $Result = $VenuesCommand.ExecuteNonQuery()
            $VenuesCommand.CommandText = "Delete From Venues"
            $Result = $VenuesCommand.ExecuteNonQuery()
            $VenuesCommand.CommandText = "Delete From City"
            $Result = $VenuesCommand.ExecuteNonQuery()
            $VenuesCommand.CommandText = "Delete From States"
            $Result = $VenuesCommand.ExecuteNonQuery()
            $VenuesCommand.CommandText = "Delete From Country"
            $Result = $VenuesCommand.ExecuteNonQuery()
            $VenuesCommand.CommandText = "Delete From WebSiteActionLog"
            $Result = $VenuesCommand.ExecuteNonQuery()
            Write-Host "Finished cleaning Venues tables."
            $VenuesCommand.CommandText =
@"
                Set Identity_Insert [dbo].[Country] On 
                Insert [dbo].[Country] ([CountryId], [CountryName], [Description]) Values (1, N'United States', NULL)
                Set Identity_Insert [dbo].[Country] Off
"@
            $Result = $VenuesCommand.ExecuteNonQuery()
            Write-Host "Table 'Country' populated with data successfully."
            $VenuesCommand.CommandText =
@"
                Set Identity_Insert [dbo].[States] On 
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (1, N'CA', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (2, N'CO', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (3, N'FL', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (4, N'MA', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (5, N'MI', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (6, N'NY', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (7, N'OR', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (8, N'TX', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (9, N'UT', NULL, 1)
                Insert [dbo].[States] ([StateId], [StateName], [Description], [CountryId]) Values (10, N'WA', NULL, 1)
                Set Identity_Insert [dbo].[States] Off
"@
            $Result = $VenuesCommand.ExecuteNonQuery()
            Write-Host "Table 'States' populated with data successfully."
            $VenuesCommand.CommandText =
@"
                Set Identity_Insert [dbo].[City] On 
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (1, N'Los Angeles', NULL, 1)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (2, N'Denver', NULL, 2)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (3, N'Jacksonville', NULL, 3)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (4, N'Boston', NULL, 4)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (5, N'Detroit', NULL, 5)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (6, N'Syracuse', NULL, 6)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (7, N'Portland', NULL, 7)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (8, N'Austin', NULL, 8)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (9, N'Salt Lake City', NULL, 9)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (10, N'Seattle', NULL, 10)
                Insert [dbo].[City] ([CityId], [CityName], [Description], [StateId]) Values (11, N'Spokane', NULL, 10)
                Set Identity_Insert [dbo].[City] Off
"@
            $Result = $VenuesCommand.ExecuteNonQuery()
            Write-Host "Table 'City' populated with data successfully."
            $VenuesCommand.CommandText =
@"
                Set Identity_Insert [dbo].[Venues] On 
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (1, N'Conrad Fischer Stands', 1000, N'', 1)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (2, N'Hayden Lawrence Gardens', 1000, N'', 2)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (3, N'Rene Charron Highrise', 1000, N'', 3)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (4, N'Aldo Richter Hall', 1000, N'', 4)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (5, N'Harriet Collier Auditorium', 1000, N'', 5)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (6, N'Samuel Boyle Center', 1000, N'', 6)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (7, N'Millie Stevens Memorial Plaza', 1000, N'', 7)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (8, N'Louisa Zimmerman Stadium', 1000, N'', 8)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (9, N'Lara Ehrle Amphitheter', 1000, N'', 9)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (10, N'Antione Lacroix Dome', 1000, N'', 10)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (11, N'Claude LAngelier Field', 1000, N'', 11)
                Insert [dbo].[Venues] ([VenueId], [VenueName], [Capacity], [Description], [CityId]) Values (12, N'Maya Haynes Arena', 1000, N'', 10)
                Set Identity_Insert [dbo].[Venues] Off
"@
            $Result = $VenuesCommand.ExecuteNonQuery()
            Write-Host "Table 'Venues' populated with data successfully."
            $VenuesCommand.CommandText =
@'
                Set Identity_Insert [dbo].[SeatSection] On 
                Declare @index numeric = 1
                Declare @venueIndex numeric = 1
                Declare @seatIndex numeric = 1
                While @venueIndex <= 12
                Begin
                    Set @seatIndex = 1
                    While @seatIndex <= 10
                    Begin
                        Insert [dbo].[SeatSection] ([SeatSectionId], [SeatCount], [VenueId], [Description])
                        Values (@index, 100, @venueIndex, N'')
                        Set @index = @index + 1
                        Set @seatIndex = @seatIndex + 1
                    End
                    Set @venueIndex = @venueIndex + 1
                End
                Set Identity_Insert [dbo].[SeatSection] Off
'@
            $Result = $VenuesCommand.ExecuteNonQuery()
            Write-Host "Table 'SeatSection' populated with data successfully."
            Write-Host "Closing connection to Venues tables..."
            $VenuesConnection.Close()
            $VenuesConnection = $null
            $VenuesCommand = $null
            $VenuesConnectionString = $null
            Write-Host "Closed connection and finished processing Venues tables." -ForegroundColor Yellow
            
            #CONCERTS
            Write-Host "Connecting to Concerts tables..."
            $ConcertsConnectionString = "Server=tcp:$ServerName.database.windows.net;Database=$DatabaseName;User ID=$UserName;Password=$Password;Trusted_Connection=False;Encrypt=True;"
            $ConcertsConnection = New-Object System.Data.SqlClient.SqlConnection($ConcertsConnectionString)
            $ConcertsCommand = New-Object System.Data.SqlClient.SqlCommand('',$ConcertsConnection)
            $ConcertsConnection.Open()
            Write-Host "Connected to Concerts tables successfully."
            Write-Host "Beginning to clean Concerts tables..."
            $ConcertsCommand.CommandText = "Delete From Concerts"
            $Result = $ConcertsCommand.ExecuteNonQuery()
            $ConcertsCommand.CommandText = "Delete From Performers"
            $Result = $ConcertsCommand.ExecuteNonQuery()
            Write-Host "Finished cleaning Concerts tables."
            $ConcertsCommand.CommandText =
@'
                Set Identity_Insert [dbo].[Concerts] On 
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (1, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-01-28 00:54:01.870' AS DateTime), 3, 1, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (2, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-01-29 00:54:01.877' AS DateTime), 3, 2, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (3, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-01-30 00:54:01.880' AS DateTime), 3, 3, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (4, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-01-31 00:54:01.887' AS DateTime), 3, 4, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (5, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-01 00:54:01.890' AS DateTime), 3, 5, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (6, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-02 00:54:01.893' AS DateTime), 3, 6, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (7, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-03 00:54:01.897' AS DateTime), 3, 7, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (8, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-04 00:54:01.900' AS DateTime), 3, 8, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (9, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-05 00:54:01.903' AS DateTime), 3, 9, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (10, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-06 00:54:01.907' AS DateTime), 3, 10, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (11, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-07 00:54:01.910' AS DateTime), 3, 11, 1, 0)
                Insert [dbo].[Concerts] ([ConcertId], [ConcertName], [Description], [ConcertDate], [Duration], [VenueId], [PerformerId], [SaveToDbServerType]) Values (12, N'Julie and the Plantes Illumination Tour', N'', Cast(N'2015-02-08 00:54:01.910' AS DateTime), 3, 12, 1, 0)
                Set Identity_Insert [dbo].[Concerts] Off
'@
            $Result = $ConcertsCommand.ExecuteNonQuery()
            Write-Host "Table 'Concerts' populated with data successfully."
            $ConcertsCommand.CommandText =
@'
                SET IDENTITY_INSERT [dbo].[Performers] ON 
                INSERT [dbo].[Performers] ([PerformerId], [FirstName], [LastName], [Skills], [ContactNbr], [ShortName]) VALUES (1, N'Julie', N'Plantes', N'PopMusic', CAST(1234567891 AS Numeric(15, 0)), N'Julie and the Plantes')                
                SET IDENTITY_INSERT [dbo].[Performers] OFF
'@
            $Result = $ConcertsCommand.ExecuteNonQuery()
            Write-Host "Table 'Performers' populated with data successfully."
            Write-Host "Closing connection to Concerts tables..."
            $ConcertsConnection.Close()
            $ConcertsConnection = $null
            $ConcertsCommand = $null
            $ConcertsConnectionString = $null
            Write-Host "Closed connection and finished processing Concerts tables." -ForegroundColor Yellow
            
            #TICKETS
            Write-Host "Connecting to Tickets tables..."
            $ConcertTicketsConnectionString = "Server=tcp:$ServerName.database.windows.net;Database=$DatabaseName;User ID=$UserName;Password=$Password;Trusted_Connection=False;Encrypt=True;"
            $ConcertTicketsConnection = New-Object System.Data.SqlClient.SqlConnection($ConcertTicketsConnectionString)
            $ConcertTicketsCommand = New-Object System.Data.SqlClient.SqlCommand('',$ConcertTicketsConnection)
            $ConcertTicketsConnection.Open()
            Write-Host "Connected to Tickets tables successfully."
            Write-Host "Beginning to clean Tickets tables..."
            $ConcertTicketsCommand.CommandText = "Delete From TicketLevels"
            $Result = $ConcertTicketsCommand.ExecuteNonQuery()
            $ConcertTicketsCommand.CommandText = "Delete From Tickets"
            $Result = $ConcertTicketsCommand.ExecuteNonQuery()
            Write-Host "Finished cleaning Concert tables."
            $ConcertTicketsCommand.CommandText =
@'
                Set Identity_Insert [dbo].[TicketLevels] On 
                Declare @index numeric = 1
                Declare @venueIndex numeric = 1
                Declare @seatIndex numeric = 1
                While @venueIndex <= 12
                Begin
                    Set @seatIndex = 1
                    While @seatIndex <= 10
                    Begin
                        Insert [dbo].[TicketLevels] ([TicketLevelId], [TicketLevel], [Description], [SeatSectionId], [ConcertId], [TicketPrice])
                        Values (@index, null, N'Level-' + Cast(@index as nvarchar(8)), @index, @venueIndex, 50 + (5*@seatIndex))
                        Set @index = @index + 1
                        Set @seatIndex = @seatIndex + 1
                    End
                    Set @venueIndex = @venueIndex + 1
                End
                Set Identity_Insert [dbo].[TicketLevels] Off
'@
            $Result = $ConcertTicketsCommand.ExecuteNonQuery()
            Write-Host "Table 'TicketLevels' populated with data successfully."
            Write-Host "Closing connection to Concert tables..."
            $ConcertTicketsConnection.Close()
            $ConcertTicketsConnection = $null
            $ConcertTicketsCommand = $null
            $ConcertTicketsConnectionString = $null
            Write-Host "Closed connection and finished processing Concert tables." -ForegroundColor Yellow

            Write-Host "Finished refreshing and populating all tables with data." -ForegroundColor Yellow
        }
        Catch { Write-Error "Error -- $Error " }
        Finally
        {
            if ($CustomersConnection -ne $null -and $CustomersConnection.State -eq "Open") { $CustomersConnection.close(); $CustomersConnection = $null; }
            if ($VenuesConnection -ne $null -and $VenuesConnection.State -eq "Open") { $VenuesConnection.close(); $VenuesConnection = $null; }
            if ($ConcertsConnection -ne $null -and $ConcertsConnection.State -eq "Open") { $ConcertsConnection.close(); $ConcertsConnection = $null; }
            if ($ConcertTicketsConnection -ne $null -and $ConcertTicketsConnection.State -eq "Open") { $ConcertTicketsConnection.close(); $ConcertTicketsConnection = $null; }
        }
    }
}